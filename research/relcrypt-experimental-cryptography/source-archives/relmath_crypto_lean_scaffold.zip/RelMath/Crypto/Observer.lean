/-
# Crypto.Observer — observer-relative indistinguishability

This is intentionally dependency-light.  It packages the idea used throughout
RelCrypt: a state is visible only through an observer/invariant.
-/
namespace RelMath
namespace Crypto

/-- An observer is any function from a state/object into an observation/invariant. -/
abbrev Observer (α β : Type) := α → β

/-- Two states are indistinguishable to observer `O` when `O` gives equal observations. -/
def Indist {α β : Type} (O : Observer α β) (x y : α) : Prop := O x = O y

namespace Indist

theorem refl {α β : Type} (O : Observer α β) (x : α) : Indist O x x := rfl

theorem symm {α β : Type} {O : Observer α β} {x y : α}
    (h : Indist O x y) : Indist O y x := h.symm

theorem trans {α β : Type} {O : Observer α β} {x y z : α}
    (hxy : Indist O x y) (hyz : Indist O y z) : Indist O x z :=
  hxy.trans hyz

end Indist

/-- Product observer: see two invariants at once. -/
def prodObserver {α β γ : Type} (O₁ : Observer α β) (O₂ : Observer α γ) :
    Observer α (β × γ) :=
  fun x => (O₁ x, O₂ x)

/-- Observer refinement: `O₂` sees no more than `O₁` if it factors through `O₁`. -/
def Refines {α β γ : Type} (O₁ : Observer α β) (O₂ : Observer α γ) : Prop :=
  ∃ f : β → γ, ∀ x, O₂ x = f (O₁ x)

/-- If `O₂` refines/factors through `O₁`, indistinguishability for `O₁` implies it for `O₂`. -/
theorem indist_of_refines {α β γ : Type} {O₁ : Observer α β} {O₂ : Observer α γ}
    (h : Refines O₁ O₂) {x y : α} (hxy : Indist O₁ x y) : Indist O₂ x y := by
  rcases h with ⟨f, hf⟩
  unfold Indist at *
  rw [hf x, hf y, hxy]

end Crypto
end RelMath
