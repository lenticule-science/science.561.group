/-
# Crypto.Gauge2Mask — order-compatible Klein gauge masking

Draft scaffold for RelCrypt.

This module isolates the `Gauge₂ = {id, neg}` subgroup of `K₄`.  This is the
subgroup usable *inside* knowledge-order monotone closure, because `neg` preserves
`≤ₖ`.  The full `K₄` is still useful for boundary whitening, but `conf` and
`negConf` reverse `≤ₖ`, so they should not be silently used inside a monotone
knowledge-closure pulse.
-/
import RelMath.Positing.KleinFourGauge

namespace RelMath
namespace Crypto
namespace Gauge2

open Charge
open RelMath.KleinFour

/-- The order-compatible gauge subgroup `Gauge₂ = {id, neg}`. -/
def Gauge2 (g : K4.K4) : Prop := K4.inGauge g = true

@[simp] theorem id_mem : Gauge2 K4.K4.id := rfl
@[simp] theorem neg_mem : Gauge2 K4.K4.neg := rfl

/-- `conf` is not in the internal knowledge-compatible gauge. -/
theorem conf_not_mem : ¬ Gauge2 K4.K4.conf := by
  intro h
  simp [Gauge2, K4.inGauge] at h

/-- `negConf` is not in the internal knowledge-compatible gauge. -/
theorem negConf_not_mem : ¬ Gauge2 K4.K4.negConf := by
  intro h
  simp [Gauge2, K4.inGauge] at h

/-- Closure of `Gauge₂` under the inherited `K₄` multiplication. -/
theorem closed {g h : K4.K4} (hg : Gauge2 g) (hh : Gauge2 h) :
    Gauge2 (K4.mul g h) :=
  K4.gauge_closed g h hg hh

/-- Every internal gauge element is self-inverse as a `K₄` element. -/
theorem self_inverse (g : K4.K4) (_hg : Gauge2 g) :
    K4.mul g g = K4.K4.id :=
  K4.mul_self g

/-- Masking and unmasking a charge by the same internal gauge element recovers it. -/
theorem mask_unmask_charge (g : K4.K4) (hg : Gauge2 g) (a : Charge) :
    K4.act g (K4.act g a) = a := by
  cases g with
  | id => rfl
  | neg =>
      cases a <;> rfl
  | conf =>
      exact False.elim (conf_not_mem hg)
  | negConf =>
      exact False.elim (negConf_not_mem hg)

/-- Internal gauge elements preserve the knowledge order. -/
theorem preserves_kle (g : K4.K4) (hg : Gauge2 g) (a b : Charge) :
    KLE (K4.act g a) (K4.act g b) ↔ KLE a b := by
  cases g with
  | id => rfl
  | neg => exact K4.neg_preserves_kle a b
  | conf => exact False.elim (conf_not_mem hg)
  | negConf => exact False.elim (negConf_not_mem hg)

/-- The `neg` gauge flips the truth order. -/
theorem neg_reverses_truth (a b : Charge) :
    TLE (K4.act K4.K4.neg a) (K4.act K4.K4.neg b) ↔ TLE b a :=
  K4.neg_reverses_tle a b

/-- Gauge-mask a valuation. -/
def maskVal (g : K4.K4) (_hg : Gauge2 g) (v : Valuation) : Valuation :=
  fun φ => K4.act g (v φ)

/-- Masking/unmasking a valuation by the same internal gauge recovers it. -/
theorem mask_unmask_valuation (g : K4.K4) (hg : Gauge2 g) (v : Valuation) :
    maskVal g hg (maskVal g hg v) = v := by
  funext φ
  exact mask_unmask_charge g hg (v φ)

end Gauge2
end Crypto
end RelMath
