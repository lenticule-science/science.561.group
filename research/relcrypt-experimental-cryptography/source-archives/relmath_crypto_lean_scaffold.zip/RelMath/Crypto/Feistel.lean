/-
# Crypto.Feistel — generic invertibility scaffold

A Feistel network is invertible even when the round function is many-to-one.
This is the formal reason RelCrypt may put lossy settling/closure observers inside
a reversible block-cipher shell.

This scaffold states the theorem over an abstract xor-like operation.
-/
namespace RelMath
namespace Crypto
namespace Feistel

/-- Minimal XOR-like structure needed for Feistel over a single branch type. -/
structure XorLike (α : Type) where
  xor : α → α → α
  xor_assoc : ∀ a b c, xor (xor a b) c = xor a (xor b c)
  xor_comm : ∀ a b, xor a b = xor b a
  xor_zero : α
  xor_zero_right : ∀ a, xor a xor_zero = a
  xor_self : ∀ a, xor a a = xor_zero

variable {α κ : Type} (X : XorLike α)

/-- One balanced Feistel round. -/
def round (F : α → κ → α) (k : κ) (p : α × α) : α × α :=
  (p.2, X.xor p.1 (F p.2 k))

/-- Inverse of one Feistel round. -/
def invRound (F : α → κ → α) (k : κ) (p : α × α) : α × α :=
  (X.xor p.2 (F p.1 k), p.1)

/-- One Feistel round followed by its inverse is identity. -/
theorem inv_round_round (F : α → κ → α) (k : κ) (p : α × α) :
    invRound X F k (round X F k p) = p := by
  cases p with
  | mk l r =>
      unfold round invRound
      simp
      -- goal reduces to xor (xor l (F r k)) (F r k) = l
      calc
        X.xor (X.xor l (F r k)) (F r k)
            = X.xor l (X.xor (F r k) (F r k)) := X.xor_assoc l (F r k) (F r k)
        _ = X.xor l X.xor_zero := by rw [X.xor_self]
        _ = l := X.xor_zero_right l

/-- Inverse followed by the round is identity. -/
theorem round_inv_round (F : α → κ → α) (k : κ) (p : α × α) :
    round X F k (invRound X F k p) = p := by
  cases p with
  | mk l r =>
      unfold round invRound
      simp
      calc
        X.xor (X.xor r (F l k)) (F l k)
            = X.xor r (X.xor (F l k) (F l k)) := X.xor_assoc r (F l k) (F l k)
        _ = X.xor r X.xor_zero := by rw [X.xor_self]
        _ = r := X.xor_zero_right r

end Feistel
end Crypto
end RelMath
