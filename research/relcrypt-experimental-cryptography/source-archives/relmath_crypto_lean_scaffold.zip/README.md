# RelMath/Crypto Lean Scaffold

Draft Lean modules for the next RelCrypt formalization pass.

These are **scaffolding files**, not security proofs. They are meant to be copied into
`emsenn/relational-math` and adjusted locally against the current module graph.

The intended first four modules:

```text
RelMath/Crypto/Gauge2Mask.lean
RelMath/Crypto/Observer.lean
RelMath/Crypto/Feistel.lean
RelMath/Crypto/SemanticPulseToy.lean
```

Design discipline:

```text
Gauge₂ = {id, neg} lives inside knowledge-order-compatible masking.
Full K₄/D₄ belong at semantic boundaries.
𝔽₂ remains the bit engine.
Settling/cohomology produce observer data, not standalone invertible ciphers.
```
