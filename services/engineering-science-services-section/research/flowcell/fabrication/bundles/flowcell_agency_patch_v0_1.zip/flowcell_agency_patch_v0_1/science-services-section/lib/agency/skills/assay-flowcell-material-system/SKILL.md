# Assay a FlowCell material system

Identify engineering function first: structure, seal, bearing, skin, membrane, electrolyte, hydraulic fluid, coating, sensor substrate or repair system.

Test applicable freshwater/seawater compatibility, galvanic/corrosion behavior, hydrolysis/UV, abrasive sediment, fouling/cleaning, hot-water decon, freeze/thaw, cyclic strain/fatigue, leakage consequence, material shedding and energy/material accounting.

For storage or active maintenance, precipitating a mineral, producing voltage once or healing once is not sufficient evidence.

Return qualified envelope, failure modes, evidence status and prohibited extrapolations.
