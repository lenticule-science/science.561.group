# Design a falsifiable FlowCell assay

Start from one claim, not from a device preference. State the claim so it could be wrong.

Record hypothesis/mechanism, exact configuration, intervention, observables, comparator, calibration/uncertainty, environment, replicates, pass threshold, fail/kill threshold, controls, safety/ecology boundary, and raw-evidence carrier.

For house mathematical/material hypotheses require a conventional comparator.

Reject assays with no losing condition, uncontrolled multi-variable changes, single-best-run evidence, or claims extending beyond the measured observable.

Return a preregistration another office can execute without reconstructing intent.
