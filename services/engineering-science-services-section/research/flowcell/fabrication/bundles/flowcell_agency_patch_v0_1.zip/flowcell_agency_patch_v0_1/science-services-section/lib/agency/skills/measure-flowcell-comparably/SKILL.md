# Measure FlowCell comparably

Bind every run to an exact configuration id and calibration set.

Preserve environment/resource state, geometry/material revision, synchronized raw traces, calibration, fixture losses, derived metrics and derivation version, replicate id, interventions, uncertainty, and pre/post inspection.

Compare candidates under shared boundary conditions. Report net power, loads, wet mass, bandwidth, intervention time and interface burden where meaningful.

Preserve failed and contradictory runs. Return raw evidence plus a bounded conclusion.
