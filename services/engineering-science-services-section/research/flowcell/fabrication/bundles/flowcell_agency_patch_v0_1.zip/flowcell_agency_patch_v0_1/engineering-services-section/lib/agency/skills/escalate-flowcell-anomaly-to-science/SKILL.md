# Escalate a FlowCell anomaly to Science

First check ordinary engineering causes: configuration mismatch, calibration, assembly defect, tolerance, firmware/control error and expected environmental variance.

Escalate only when mismatch materially violates a qualified model/claim, repeats, exposes a new regime, or resists ordinary engineering closure.

Return exact configuration, expected claim, observation, mismatch magnitude, raw evidence, reproduction, checked causes and one discriminating scientific question.
