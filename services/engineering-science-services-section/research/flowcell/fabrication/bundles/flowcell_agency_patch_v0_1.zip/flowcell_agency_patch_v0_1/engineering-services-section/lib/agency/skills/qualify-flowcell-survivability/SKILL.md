# Qualify FlowCell survivability

Bind every result to one configuration id.

Maintain FMEA/hazard and verification matrices for applicable sediment, scour, debris, weeds/trash, fishing gear, fish-surrogate exposure/ecological monitoring, fouling/cleaning, AIS drain/decon, freeze/ice, fluid leaks, tether fatigue, human misuse, sensor blindness, condensation/seepage, UV/weather and dead-machine recovery.

Clean-water power tests never by themselves release a field configuration.

Return pass/fail/conditional records, deviations, residual risks and next gate.
