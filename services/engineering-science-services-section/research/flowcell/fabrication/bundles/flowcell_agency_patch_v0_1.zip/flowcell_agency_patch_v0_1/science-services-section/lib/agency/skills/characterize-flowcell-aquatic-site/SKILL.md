# Characterize a FlowCell aquatic site

Build a coupled hydraulic/ecological/operational envelope rather than reporting one velocity.

Include current distribution, turbulence/extremes, bathymetry/substrate, sediment/scour, debris/fishing exposure, ice/seasonality, conductivity/salinity/temperature, ecological receptors, AIS/decon, navigation/human use, jurisdiction unknowns, and dead-recovery access.

Label unknowns as unknowns and produce the minimum measurement plan needed to qualify or reject the site.
