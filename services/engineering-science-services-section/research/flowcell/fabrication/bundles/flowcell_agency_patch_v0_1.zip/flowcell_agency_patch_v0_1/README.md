# FlowCell Agency Patch v0.1

A proposed drop-in agency package for the live FlowCell institution-building requests.

It contains:
- Lenticule Science office/duty/work/skill records;
- Red Cup Engineering office/duty/work/skill records;
- science↔engineering packet schemas;
- FlowCell maturity gates;
- closed-loop operating model;
- manifest with live MetroPlat thread identifiers.

**Important:** these files are proposals for authorized enactment. Creating this package does not itself admit agency records.
