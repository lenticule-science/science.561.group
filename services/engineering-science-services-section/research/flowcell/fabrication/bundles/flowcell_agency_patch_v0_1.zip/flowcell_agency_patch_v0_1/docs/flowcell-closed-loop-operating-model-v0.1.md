# FlowCell Closed-Loop Operating Model v0.1

## Lenticule Science loop
1. Receive a question, anomaly, or candidate scientific claim.
2. Reuse existing Research/Mathematics/Computation/Obsmetrologia capability where it already exists.
3. Preregister a discriminating assay.
4. Require comparable metrology and preserve raw/negative evidence.
5. Update claim maturity.
6. Qualify a bounded claim to Engineering or return an unresolved scientific question.
7. Choose the next assay by expected information gain: prefer experiments likely to change a design, retire a branch, or narrow a scientific claim.

## Red Cup Engineering loop
1. Read accepted requirements, qualified claims, released configuration and open hazards.
2. Maintain the digital thread before changing hardware.
3. Co-design across hydrodynamics, structure, control, materials, ecology, maintenance and manufacturing.
4. Build the smallest article that can falsify the current choice.
5. Verify useful energy and mundane survivability together.
6. Return persistent model/claim anomalies to Science.
7. Advance maturity only when the gate evidence is held.
8. Productize only a stable bounded baseline; leave experimental organs modular.

## Self-improvement rule
Every cycle may improve the process itself, but only from observed friction:
- missing measurement;
- repeated handoff ambiguity;
- duplicate work;
- orphaned evidence;
- slow/expensive assay;
- configuration ambiguity;
- failure discovered too late.

Process changes require the same discipline as hardware changes: state the failure, proposed mechanism, observable improvement, comparator, and rollback condition.

## Optimization
Do not optimize one scalar prematurely.

Maintain a Pareto front over:
- lifetime useful service;
- human intervention;
- net energy;
- peak/fatigue loads;
- ecological exposure;
- recoverability;
- submerged interface tax;
- manufacturing cost;
- field service cost;
- modular upgrade value.

Scalarize only for a specific customer/product decision.
