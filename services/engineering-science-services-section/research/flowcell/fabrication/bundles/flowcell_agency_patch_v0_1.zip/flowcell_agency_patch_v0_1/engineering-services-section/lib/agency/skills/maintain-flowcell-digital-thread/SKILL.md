# Maintain the FlowCell digital thread

Trace:
requirement -> qualified claim/model -> configuration -> test protocol -> raw evidence -> verification result -> anomaly/disposition -> revision -> manufacturing release.

Every artifact names its dependencies. Never overwrite contradictory evidence; supersede it.

A test result without exact configuration is non-release evidence. A design decision without requirement, qualified claim or explicit trade rationale is an orphan.
