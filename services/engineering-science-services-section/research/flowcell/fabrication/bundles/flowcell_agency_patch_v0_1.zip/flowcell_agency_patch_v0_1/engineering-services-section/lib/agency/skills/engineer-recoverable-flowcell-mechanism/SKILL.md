# Engineer a recoverable FlowCell mechanism

Design wet load path, converter mechanics, current alignment/reversal, mooring/tether, lifting, deployment, service access and passive dead-state recovery.

Cover normal, startup/shutdown, load rejection, debris, snag/misuse, extreme current, transport/retrieval, fatigue, and applicable wave/ice/scour cases.

A recovery claim cannot depend solely on telemetry, powered actuators or active buoyancy.

Return buildable geometry requirements, load cases, proof tests, service procedure and open risks.
