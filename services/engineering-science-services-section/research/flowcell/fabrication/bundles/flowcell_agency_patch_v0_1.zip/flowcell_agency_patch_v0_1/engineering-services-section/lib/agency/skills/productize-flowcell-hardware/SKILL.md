# Productize FlowCell hardware

Maintain BOM/AVL, make/buy, drawing/CAD revision, tolerances/inspection, material/process specs, assembly, calibration/end-of-line test, service parts, cleaning/decon, packaging, supplier RFQs, tooling/MOQ assumptions, landed-cost model, certification evidence and warranty/recovery assumptions.

EVT proves architecture and measurement.
DVT proves design, survivability and repeatability.
PVT proves production process and inspection/test.

Research-only chemistry/materials do not silently enter the launch baseline.
