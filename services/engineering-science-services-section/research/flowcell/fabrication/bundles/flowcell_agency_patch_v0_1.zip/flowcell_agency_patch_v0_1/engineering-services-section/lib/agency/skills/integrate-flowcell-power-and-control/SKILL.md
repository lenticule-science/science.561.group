# Integrate FlowCell power and control

Define PTO/generator interface, conversion, loading/MPPT, brake/dump/overpressure paths, storage, auxiliary inputs, telemetry, local state machine, comms-loss behavior, insulation/leak monitoring and customer/FlowPort interfaces.

Fast safety remains local. Loss of ESS, network or supervisory compute must not remove independent overspeed/overpressure protection.

Experimental formal control stays shadow-mode until it beats its conventional comparator.
