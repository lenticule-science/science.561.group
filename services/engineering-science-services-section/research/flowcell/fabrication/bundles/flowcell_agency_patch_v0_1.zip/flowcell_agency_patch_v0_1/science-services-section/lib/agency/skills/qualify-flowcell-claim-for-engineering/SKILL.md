# Qualify a FlowCell claim for Engineering

Read preregistration, exact configuration, raw evidence, analysis, uncertainty, controls, failures and deviations.

Return one status: qualified, qualified-with-bounds, not-qualified, or contradicted.

Carry claim text, evidence maturity, configurations, environment/operating envelope, comparator, effect/metrics, uncertainty, replication, confounders, raw evidence and prohibited extrapolations.

Engineering may use the claim only inside this envelope.
