# Co-design the FlowCell system

Maintain one configuration-controlled system model from accepted requirements, qualified science, verification evidence and manufacturing constraints.

Do not begin from 'turbine.' Keep viable morphologies alive until gates close them.

For each trade compare shared boundary conditions across power/service value, structural load, intervention, ecological exposure, interface tax, mass, cost, manufacturing and recovery. Keep a Pareto set until a requirement justifies scalarization.

Return requirements revision, interface revision, configuration baseline, trade record, verification methods and unresolved science/engineering risks.
