# FlowCell Maturity Gates v0.1

## G0 — Hypothesis admitted
Required:
- explicit claim;
- known evidence status;
- falsifiable assay;
- comparator/control;
- kill criterion;
- configuration or material identity.

No hardware scale-up.

## G1 — Tabletop/bench evidence
Required:
- calibrated instrumentation;
- repeatable signal above measurement uncertainty;
- fixture losses accounted;
- at least three runs where meaningful;
- negative/failed runs preserved.

May advance to controlled-water article.

## G2 — Controlled-water morphology evidence
Required:
- common resource measurement;
- power/load/intervention metrics;
- survival of basic sediment/debris challenge appropriate to article;
- configuration-controlled geometry;
- no unresolved safety failure.

May remain a product challenger.

## G3 — Integrated EVT
Required:
- recoverable integrated configuration;
- safe independent shutdown/protection;
- dead-state recovery method;
- exact digital thread;
- minimum mundane survivability set completed;
- no launch-critical unqualified chemistry/material.

May advance to DVT.

## G4 — DVT
Required:
- representative design;
- repeatable performance across intended envelope;
- fatigue/service evidence;
- AIS/decon compatibility for portable freshwater hardware;
- environmental/site monitoring plan;
- field-relevant debris/fouling/sensor-blindness testing;
- ≥100 cumulative wet hours target unless a different justified gate is adopted;
- ≥10 deployment/retrieval cycles target.

May advance to pilot/PVT.

## G5 — Pilot field qualification
Required:
- site-specific resource/ecology/navigation/jurisdiction envelope;
- approved deployment/monitoring path;
- field power/resource data;
- documented interventions/failures;
- dead recovery demonstrated or independently credible for the field configuration;
- no unexplained safety-critical anomaly.

May freeze production candidate.

## G6 — PVT
Required:
- supplier/sample lot;
- controlled BOM/AVL;
- incoming inspection;
- assembly work instructions;
- calibration/end-of-line test;
- packaging/logistics;
- service parts;
- warranty/recovery assumptions;
- manufacturing yield evidence.

May launch a bounded first production run.

## G7 — Production learning
Required:
- field returns and service evidence;
- configuration-specific reliability;
- manufacturing drift monitoring;
- ecology/survivability feedback;
- science anomaly returns when models fail.

Production is not the end of experimentation.
