# Return a FlowCell anomaly to Science

Accept an anomaly only after ordinary engineering causes are checked enough to distinguish a scientific mismatch.

Carry configuration id, expected model/claim, observed behavior, mismatch magnitude, raw traces, calibration, reproduction count, implementation causes checked, environment, safety/ecological consequence and one discriminating scientific question.

Never return merely 'it behaved weirdly.'
