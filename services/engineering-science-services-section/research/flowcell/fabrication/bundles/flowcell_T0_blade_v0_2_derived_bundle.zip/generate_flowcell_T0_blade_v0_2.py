#!/usr/bin/env python3
"""
FlowCell T0 NACA 4412 blade generator — v0.2-derived

Derived from documented FlowCell fabrication stations:
 radius mm | chord mm | twist deg
 15.0      | 29.0     | 21
 30.0      | 25.0     | 15
 45.0      | 21.0     | 10
 60.0      | 18.0     | 6
 75.5      | 15.0     | 2

IMPORTANT:
- This is NOT the historical v0.1 mesh.
- It assumes a standard NACA 4412 section and twists each station about
  the local quarter-chord.
- Coordinates: x = chordwise, y = radial, z = section thickness.
- Intended first use is a non-rotating fabrication/measurement article.
- Do not use for wet/high-speed rotation without full engineering review,
  proper hub/shaft interfaces, balancing, guarding, and acceptance testing.
"""
import numpy as np, math, struct

STATIONS = np.array([
    [15.0, 29.0, 21.0],
    [30.0, 25.0, 15.0],
    [45.0, 21.0, 10.0],
    [60.0, 18.0,  6.0],
    [75.5, 15.0,  2.0],
], dtype=float)

M, P, T = 0.04, 0.40, 0.12
N_HALF = 81

def naca4412_profile():
    beta = np.linspace(0, np.pi, N_HALF)
    x = (1 - np.cos(beta)) / 2
    yt = 5*T*(0.2969*np.sqrt(np.maximum(x,1e-12)) - 0.1260*x
              - 0.3516*x**2 + 0.2843*x**3 - 0.1015*x**4)
    yc = np.where(x < P,
                  M/P**2 * (2*P*x - x**2),
                  M/(1-P)**2 * ((1-2*P) + 2*P*x - x**2))
    dy = np.where(x < P, 2*M/P**2*(P-x), 2*M/(1-P)**2*(P-x))
    th = np.arctan(dy)
    xu, yu = x - yt*np.sin(th), yc + yt*np.cos(th)
    xl, yl = x + yt*np.sin(th), yc - yt*np.cos(th)
    return np.vstack([np.column_stack([xu[::-1], yu[::-1]]),
                      np.column_stack([xl[1:], yl[1:]])])

def section(profile, r, chord, twist):
    x = profile[:,0]*chord
    z = profile[:,1]*chord
    q = 0.25*chord
    xr = x-q
    a = math.radians(twist)
    X = xr*np.cos(a)-z*np.sin(a)+q
    Z = xr*np.sin(a)+z*np.cos(a)
    return np.column_stack([X, np.full_like(X,r), Z])

def mesh():
    p = naca4412_profile()
    npf = len(p)
    V = np.vstack([section(p,*s) for s in STATIONS])
    F = []
    for si in range(len(STATIONS)-1):
        a0,b0=si*npf,(si+1)*npf
        for j in range(npf):
            jn=(j+1)%npf
            a,b,c,d=a0+j,a0+jn,b0+jn,b0+j
            F += [[a,b,c],[a,c,d]]
    root=len(V); tip=root+1
    V=np.vstack([V,V[:npf].mean(0),V[-npf:].mean(0)])
    for j in range(npf):
        jn=(j+1)%npf
        F.append([root,jn,j])
        a=(len(STATIONS)-1)*npf
        F.append([tip,a+j,a+jn])
    return V,np.asarray(F,dtype=np.int32)

def write_stl(path,V,F):
    def normal(a,b,c):
        n=np.cross(b-a,c-a); L=np.linalg.norm(n)
        return n/L if L>1e-12 else np.zeros(3)
    with open(path,"wb") as f:
        f.write(b"FlowCell T0 NACA4412 v0.2-derived".ljust(80,b" "))
        f.write(struct.pack("<I",len(F)))
        for face in F:
            a,b,c=V[face]; n=normal(a,b,c)
            f.write(struct.pack("<3f",*n.astype(np.float32)))
            for v in (a,b,c): f.write(struct.pack("<3f",*v.astype(np.float32)))
            f.write(struct.pack("<H",0))

if __name__=="__main__":
    V,F=mesh()
    write_stl("flowcell_T0_blade_NACA4412_v0_2_derived.stl",V,F)
    print("vertices",len(V),"faces",len(F))
    print("bounds mm",V.min(0),V.max(0))
