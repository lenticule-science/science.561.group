# FlowCell T0 blade — v0.2-derived

Generated: 2026-10-02

## Status

This is a newly derived manufacturing geometry from the documented FlowCell
T0 NACA4412 blade stations. It is **not** the missing historical v0.1 STL.

Explicit added assumption:
- standard NACA 4412 section;
- cosine-sampled airfoil coordinates;
- section twist applied about local quarter-chord.

Coordinate convention:
- x: chordwise;
- y: radial;
- z: section thickness.

## Mesh

- vertices: 807
- triangular faces: 1610
- watertight edge-manifold check: True
- bounds min mm: [-0.003945100580348804, 15.0, -2.8697316957924546]
- bounds max mm: [27.563845667824793, 75.5, 7.830047341357757]
- bounding-box dimensions mm: [27.567790768405143, 60.5, 10.699779037150211]
- signed-volume magnitude: 2383.4 mm^3
- surface area: 2754.5 mm^2

## First fabrication purpose

Print **one blade as a non-rotating dimensional/process article** before
making a three-blade set or rotor. The purpose is to qualify printer +
material + orientation + finishing against the FlowCell fabrication gates.

Acceptance checks:
1. chord at the documented radial stations within ±0.25 mm where measurable;
2. visually smooth leading edge without support scars;
3. no delamination, voids, or obvious layer cracks;
4. record material, nozzle, layer height, walls/infill, orientation, drying,
   slicer/profile, estimated and actual mass/time, and operator intervention;
5. if three blades are later made, use identical orientation/post-processing
   and target <1% finished mass spread where practical.

This model contains **no engineered root socket/hub torque interface**. Do not
put this derived blade into a rotating wet test merely because it prints.
The documented FlowCell plan requires a proper 8 mm shaft/coupling interface,
balancing, guarding, emergency load/brake, inspection, and the rest of the
test fixture before rotation.

## Files

- flowcell_T0_blade_NACA4412_v0_2_derived.stl
- flowcell_T0_blade_NACA4412_v0_2_derived.obj
- generate_flowcell_T0_blade_v0_2.py

## Shop-ready additions

- `flowcell_T0_blade_NACA4412_v0_2_derived_ROOT_ON_BED.stl` — same derived
  blade mesh transformed to root-on-bed print coordinates.
- `first_article_inspection_targets.csv` — documented station targets.
- `FIRST_ARTICLE_JOB_CARD.md` — bounded print/inspection procedure.
